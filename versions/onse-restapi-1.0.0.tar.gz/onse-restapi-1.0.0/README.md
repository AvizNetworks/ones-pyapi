# ones-restapi 
ONES SDK for developers and Network Engineers

PS - This is still in <b>POC phase</b>.

POC video - https://drive.google.com/file/d/1OeAtFak9pixwO1Q3HJhnrflJCe0QbK9H/view?usp=sharing <br />
Documentation - https://docs.google.com/document/d/1ZL_lnisTJwfpxAQ-pqxIMPS5mfjOmrilV-WsX694pcM/edit#heading=h.ca9dqvsar3xe


