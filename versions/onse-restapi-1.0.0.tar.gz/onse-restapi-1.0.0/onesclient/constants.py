HARDWARE_INFO_ERROR = "something went wrong, not able to fetch hardware info.."
ROLES_ERROR = "something went wrong, not able to fetch roles"